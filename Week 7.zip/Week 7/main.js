
let board = ["", "", "", "", "", "", "", "", ""]
let turn= 0
let canPlay = true;
//make based on winning player
//Game has 9 turns at max to bring a draw 
const winRequires = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6]

];
//for each space on the board what happens
document.querySelectorAll('.box').forEach (item => {
    item.addEventListener('click', event => {
        if(!canPlay){ return; }
        let eventId = event.target.getAttribute('id')
        let eventValue = event.target.getAttribute('num')
        event.target.classList.add('noClick');

        if ( turn% 2 === 0){

            document.querySelector(`#`+ eventId ).innerHTML = "x"
            board[eventValue] = "x"
            compareNum()
        }
        else{

            document.querySelector(`#`+ eventId).innerHTML = "o"
            board[eventValue] = "o"
            compareNum()
        }
           turn++

        if (turn=== 9){
          document.querySelector(".winnersCircle").innerHTML = "Game Over"
        }
        //winners circle announcement
        //winner events
        function compareNum(){
          let winRound = false
          for(let i = 0; i <= 7; i++) {
            const winEvent = winRequires[i];
            let a = board[winEvent[0]];
            let b = board[winEvent[1]];
            let c = board[winEvent[2]];
            if (a === '' || b === '' || c === '') {
              continue;

        }
          if (a === b && b === c) {
           
            if ( turn% 2 === 0){
              increaseOneScore()
                document.querySelector(".winnersCircle").innerHTML = "pOne Wins"
            }
            else{
              increaseTwoScore()
                document.querySelector(".winnersCircle").innerHTML = "pTwo Wins"
            }

            canPlay = false;
            

        }



        }
        } 
    })

})
//add to score of winning player
function increaseOneScore(){
	document.getElementById("pOne").innerHTML=+document.getElementById("pOne").innerHTML+1;
}
function increaseTwoScore(){
	document.getElementById("pTwo").innerHTML=+document.getElementById("pTwo").innerHTML+1;
}
function restart(){
  turn=0
  board = ["", "", "", "", "", "", "", "", ""]
console.log("click")
document.querySelectorAll('.noClick').forEach (item => {
  item.innerHTML=""
  item.classList.remove('noClick')
})
canPlay=true
}
document.getElementById("startOver") .addEventListener("click",restart)